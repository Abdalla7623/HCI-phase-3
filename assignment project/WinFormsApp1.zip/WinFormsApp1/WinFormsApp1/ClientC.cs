﻿namespace WinFormsApp1
{
    internal class ClientC
    {
        private Form2 form2;

        public ClientC(Form2 form2)
        {
            this.form2 = form2;
        }
    }
}