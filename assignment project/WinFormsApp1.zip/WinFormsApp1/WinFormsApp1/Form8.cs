﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form8 : Form
    {

        List<img80> imgList = new List<img80>();
        List<img81> img2 = new List<img81>();
        List<img82> img12 = new List<img82>();
        List<img83> img13 = new List<img83>();

        Bitmap off = new Bitmap(2000, 1000);
        int x = 50;
        int y = 50;
        float w = 30;
        float h = 30;

        class ClientC
        {
            int byteCount;
            NetworkStream stream;
            byte[] sendData;
            TcpClient tcpClient;

            public bool connectToSocket(String host, int portNumber)
            {
                try
                {
                    tcpClient = new TcpClient(host, portNumber);
                    stream = tcpClient.GetStream();
                    Console.WriteLine("Connection Made ! with " + host);
                    return true;
                }
                catch (System.Net.Sockets.SocketException e)
                {
                    Console.WriteLine("Connection Failed: " + e);
                    return false;
                }
            }

            public bool recieveMessage()
            {
                try
                {
                    // Receive some data from the peer.
                    byte[] receiveBuffer = new byte[1024];
                    int bytesReceived = stream.Read(receiveBuffer);
                    string data = Encoding.UTF8.GetString(receiveBuffer.AsSpan(0, bytesReceived));

                    if (data == "exit")
                    {
                        return false;
                    }

                    string[] points = data.Split(",");

                    for (int i = 0; i < points.Length; i++)
                    {
                        Console.WriteLine(points[i]);
                    }

                    // Check if the received data is "mado" and open a new form if it is
                    if (data == "'prev'")
                    {
                        // Open a new form or perform the desired action when "'prev'" is received
                        OpenNewForm();
                    }
                    //else if (data == "'next'")
                    //{
                    //    opentnextform();

                    //}
                    else if (data == "'center'")
                    {
                        // Do something for "center"
                        openthisform();
                    }
                    else
                    {
                        Console.WriteLine("login failed");
                    }

                    return true;
                }
                catch (Exception e)
                {
                    Console.WriteLine("Connection not initialized : " + e);
                    return false;
                }
            }

            private void OpenNewForm()
            {
                Form8.ActiveForm.Close();
                Form4 form4 = new Form4();
                form4.Show();

            }
            private void opentnextform()
            {
                Form3.ActiveForm.Close();
                Form4 form4 = new Form4();
                form4.Show();

            }
            private void openthisform()
            {
                Form8.ActiveForm.Close();
                Form9 form9 = new Form9();
                form9.Show();


            }


            private bool IsProcessRunning(string processName)
            {
                Process[] processes = Process.GetProcessesByName(processName);
                return processes.Length > 0;
            }
            public bool closeConnection()
            {

                stream.Close();
                tcpClient.Close();
                Console.WriteLine("Connection terminated ");
                return true;
            }


        }

        public Form8()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;

        }

        private void Form8_Load(object sender, EventArgs e)
        {
            create();
            createreport();
            //createnext();
            createlog();
            this.Paint += Form8_Paint; ;
            this.WindowState = FormWindowState.Normal;
            ClientC c = new ClientC();
            DrawDubb(this.CreateGraphics(), c);
            c.connectToSocket("127.0.0.1", 6000);
            while (true)
            {
                bool resp = c.recieveMessage();
                if (!resp)
                {
                    break;
                }

            }

            c.closeConnection();
        }

        private void Form8_Paint(object? sender, PaintEventArgs e)
        {
            throw new NotImplementedException();
        }

        void DrawDubb(Graphics g, ClientC c)
        {
            Graphics g2 = Graphics.FromImage(off);
            DrawScene(g2, c);
            g.DrawImage(off, 0, 0);
        }
        void DrawScene(Graphics g, ClientC c)
        {
            g.Clear(Color.White);
            for (int i = 0; i < imgList.Count; i++)
            {
                img80 img = imgList[i];
                g.DrawImage(img.bmp, img.y, img.x, GraphicsUnit.Pixel);
            }

            for (int i = 0; i < img2.Count; i++)
            {
                img81 img_report = img2[i];
                g.DrawImage(img_report.bmp, img_report.x, img_report.y, img_report.w, img_report.h);
            }
            for (int i = 0; i < img12.Count; i++)
            {
                img82 img_log = img12[i];
                g.DrawImage(img_log.bmp, img_log.x, img_log.y, img_log.w, img_log.h);
            }
            for (int i = 0; i < img13.Count; i++)
            {
                img83 img_log = img13[i];
                g.DrawImage(img_log.bmp, img_log.x, img_log.y, img_log.w, img_log.h);
            }
        }

        void create()
        {
            img80 img = new img80();
            img.bmp = new Bitmap("museum.jpg");
            img.y = new Rectangle(0, 0, this.ClientSize.Width, this.ClientSize.Height);
            img.x = new Rectangle(0, 0, img.bmp.Width, img.bmp.Height);
            imgList.Add(img);
        }
        //void createnext()
        //{
        //    img83 img = new img83();
        //    img.bmp = new Bitmap("next.jpg");
        //    img.x = 580;
        //    img.y = 20;
        //    img.w = img.bmp.Width;
        //    img.h = img.bmp.Height;
        //    img13.Add(img);
        //}
        void createlog()
        {
            img82 img = new img82();
            img.bmp = new Bitmap("previous.jpg");
            img.x = 30;
            img.y = 20;
            img.w = 186;
            img.h = 51;
            img12.Add(img);
        }
        void createreport()
        {
            img81 img = new img81();
            img.bmp = new Bitmap("detect.jpg");
            img.x = 200;
            img.y = 200;
            img.w = img.bmp.Width;
            img.h = img.bmp.Height;
            img2.Add(img);
        }
    }

    class img80
    {
        public Rectangle y;
        public Rectangle x;
        public Bitmap bmp;
    }

    class img81
    {
        public int x, y, w, h;
        public Bitmap bmp;
    }
    class img82
    {
        public int x, y, w, h;
        public Bitmap bmp;

    }
    class img83
    {
        public int x, y, w, h;
        public Bitmap bmp;

    }
}
