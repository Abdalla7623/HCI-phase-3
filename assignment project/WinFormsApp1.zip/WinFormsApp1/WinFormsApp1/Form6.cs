﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form6 : Form
    {
        List<img40> imgList = new List<img40>();
        List<img42> img2 = new List<img42>();

        Bitmap off = new Bitmap(2000, 1000);
        int x = 50;
        int y = 50;
        float w = 30;
        float h = 30;

        class ClientC
        {
            public int x = 50;
            public int y = 50;
            float w = 30;
            float h = 30;
            int byteCount;
            NetworkStream stream;
            byte[] sendData;
            TcpClient tcpClient;

            public bool connectToSocket(String host, int portNumber)
            {
                try
                {
                    tcpClient = new TcpClient(host, portNumber);
                    stream = tcpClient.GetStream();
                    Console.WriteLine("Connection Made ! with " + host);
                    return true;
                }
                catch (System.Net.Sockets.SocketException e)
                {
                    Console.WriteLine("Connection Failed: " + e);
                    return false;
                }
            }

            public bool recieveMessage()
            {
                try
                {
                    // Receive some data from the peer.
                    byte[] receiveBuffer = new byte[1024];
                    int bytesReceived = stream.Read(receiveBuffer);
                    string data = Encoding.UTF8.GetString(receiveBuffer.AsSpan(0, bytesReceived));
                    if (data == "exit")
                    {
                        return false;

                    }
                    string[] points = data.Split(",");
                    if (points.Length > 1)
                    {
                        for (int i = 0; i < points.Length; i++)
                        {
                            if (i == 0)
                            {
                                x = int.Parse(points[0]);
                                Console.WriteLine(points[0]);
                                y = int.Parse(points[1]);
                                Console.WriteLine(points[1]);
                                break;
                            }
                        }
                    }
                    return true;
                }
                catch (Exception e)
                {
                    Console.WriteLine("Connection not initialized : " + e);
                    return false;
                }
            }

            public bool closeConnection()
            {
                stream.Close();
                tcpClient.Close();
                Console.WriteLine("Connection terminated ");
                return true;
            }
        }
        public Form6()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }
        void create()
        {
            img40 img = new img40();
            img.bmp = new Bitmap("museum.jpg");
            img.y = new Rectangle(0, 0, this.Width, this.Height);
            img.x = new Rectangle(0, 0, img.bmp.Width, img.bmp.Height);
            imgList.Add(img);
        }


        void createreport()
        {
            img42 img = new img42();
            img.bmp = new Bitmap("previous.jpg");
            img.x = 200;
            img.y = 250;
            img.w = 400;
            img.h = 100;
            img2.Add(img);
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            create();
            createreport();
            this.Paint += Form6_Paint;
            this.WindowState = FormWindowState.Normal;

            ClientC c = new ClientC();
            c.connectToSocket("127.0.0.1", 5200);
            DrawDubb(this.CreateGraphics(), c);
            while (true)
            {
                bool resp = c.recieveMessage();
                if (!resp)
                {
                    break;
                }


            }

            c.closeConnection();
        }
        void DrawScene(Graphics g, ClientC c)
        {
            g.Clear(Color.White);
            for (int i = 0; i < imgList.Count; i++)
            {
                img40 img = imgList[i];
                g.DrawImage(img.bmp, img.y, img.x, GraphicsUnit.Pixel);
            }

            for (int i = 0; i < img2.Count; i++)
            {

                img42 img_report = img2[i];
                g.DrawImage(img_report.bmp, img_report.x, img_report.y, img_report.w, img_report.h);
            }

        }
        private bool IsProcessRunning(string processName)
        {
            Process[] processes = Process.GetProcessesByName(processName);
            return processes.Length > 0;
        }
        void DrawDubb(Graphics g, ClientC c)
        {
            Graphics g2 = Graphics.FromImage(off);
            DrawScene(g2, c);
            g.DrawImage(off, 0, 0);
        }

        private void Form6_Paint(object? sender, PaintEventArgs e)
        {
            ClientC c = new ClientC();
            off = new Bitmap(this.ClientSize.Width, this.ClientSize.Height);
            DrawDubb(e.Graphics, c);
        }
    }
    class img40
    {
        public Rectangle y;
        public Rectangle x;
        public Bitmap bmp;

    }

    class img42
    {
        public int x, y, w, h;
        public Bitmap bmp;

    }
}
